﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using HRD.Enties;
using HRD.Exceptions;


namespace HRD.DAL
{
    public class EmployeeDAL
    {
        public bool InsertEmployee(Employee objEmployee)
        {
            bool employeeAdded;
            try
            {
                SqlConnection objCon = new SqlConnection(ConfigurationManager.ConnectionStrings["HRDConnectionString"].ToString());
                SqlCommand objCom = new SqlCommand("[46008413].[InsertEmployee]", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                SqlParameter objSqlParam_ID = new SqlParameter("@ID", SqlDbType.Int);
                SqlParameter objSqlParam_Name = new SqlParameter("@Name", SqlDbType.VarChar);
                SqlParameter objSqlParam_Designation = new SqlParameter("@Designation", SqlDbType.Int);
                SqlParameter objSqlParam_Department = new SqlParameter("@Department", SqlDbType.Int);

                //

                objSqlParam_ID.Direction = ParameterDirection.Input;
                objSqlParam_Name.Direction = ParameterDirection.Input;
                objSqlParam_Designation.Direction = ParameterDirection.Input;
                objSqlParam_Department.Direction = ParameterDirection.Input;

                //

                objSqlParam_ID.Value = objEmployee.Id;
                objSqlParam_Name.Value = objEmployee.Name;
                objSqlParam_Designation.Value = objEmployee.Designation;
                objSqlParam_Department.Value = objEmployee.Department;
                //

                objCom.Parameters.Add(objSqlParam_ID);
                objCom.Parameters.Add(objSqlParam_Name);
                objCom.Parameters.Add(objSqlParam_Designation);
                objCom.Parameters.Add(objSqlParam_Department);

                //


                objCon.Open();
                objCom.ExecuteNonQuery();
                employeeAdded = true;
                objCon.Close();




            }
            catch (SqlException objSqlEx)
            {
                throw new HRDException(objSqlEx.Message);

            }
            catch (Exception objEx)
            {
                throw new HRDException(objEx.Message);

            }
            return employeeAdded;
        }


        //  


        public bool UpdateEmployee(Employee objEmployee)
        {
            bool employeeUpdated;
            try
            {
                SqlConnection objCon = new SqlConnection(ConfigurationManager.ConnectionStrings["HRDConnectionString"].ToString());
                SqlCommand objCom = new SqlCommand("[46008413].[UpdateEmployee]", objCon);
                objCom.CommandType = CommandType.StoredProcedure;

                //
                SqlParameter objSqlParam_ID = new SqlParameter("@ID", objEmployee.Id);
                SqlParameter objSqlParam_Name = new SqlParameter("@Name", objEmployee.Name);
                SqlParameter objSqlParam_Designation = new SqlParameter("@Designation", objEmployee.Designation);
                SqlParameter objSqlParam_Department = new SqlParameter("@Department", objEmployee.Department);

                //

                //objSqlParam_ID.Direction = ParameterDirection.Input;
                //objSqlParam_Name.Direction = ParameterDirection.Input;
                //objSqlParam_Designation.Direction = ParameterDirection.Input;
                //objSqlParam_Department.Direction = ParameterDirection.Input;

                //

                objCom.Parameters.Add(objSqlParam_ID);
                objCom.Parameters.Add(objSqlParam_Name);
                objCom.Parameters.Add(objSqlParam_Designation);
                objCom.Parameters.Add(objSqlParam_Department);

                //


                objCon.Open();
                objCom.ExecuteNonQuery();
                employeeUpdated = true;
                objCon.Close();




            }
            catch (SqlException objSqlEx)
            {
                throw new HRDException(objSqlEx.Message);

            }
            catch (Exception objEx)
            {
                throw new HRDException(objEx.Message);

            }
            return employeeUpdated;
        }

        public bool DeleteEmployee(int Id)
        {
            bool employeeDeleted;
            try
            {
                SqlConnection objCon = new SqlConnection(ConfigurationManager.ConnectionStrings["HRDConnectionString"].ToString());
                SqlCommand objCom = new SqlCommand("[46008413].[DeleteEmployee]", objCon);
                objCom.CommandType = CommandType.StoredProcedure;

                //
                SqlParameter objSqlParam_ID = new SqlParameter("@ID", Id);

                //SqlParameter objSqlParam_Name = new SqlParameter("@Name", objEmployee.Name);
                //SqlParameter objSqlParam_Designation = new SqlParameter("@Designation", objEmployee.Designation);
                //SqlParameter objSqlParam_Department = new SqlParameter("@Department", objEmployee.Department);

                //

                //objSqlParam_ID.Direction = ParameterDirection.Input;
                //objSqlParam_Name.Direction = ParameterDirection.Input;
                //objSqlParam_Designation.Direction = ParameterDirection.Input;
                //objSqlParam_Department.Direction = ParameterDirection.Input;

                //

                objCom.Parameters.Add(objSqlParam_ID);

                //objCom.Parameters.Add(objSqlParam_Name);
                //objCom.Parameters.Add(objSqlParam_Designation);
                //objCom.Parameters.Add(objSqlParam_Department);

                //


                objCon.Open();
                objCom.ExecuteNonQuery();
                employeeDeleted = true;
                objCon.Close();




            }
            catch (SqlException objSqlEx)
            {
                throw new HRDException(objSqlEx.Message);

            }
            catch (Exception objEx)
            {
                throw new HRDException(objEx.Message);

            }
            return employeeDeleted;
        }

        public Employee SearchEmployee(int Id)
        {

            Employee objEmployee;
            try
            {
                SqlConnection objCon = new SqlConnection(ConfigurationManager.ConnectionStrings["HRDConnectionString"].ToString());
                SqlCommand objCom = new SqlCommand("[46008413].[SelectEmployeeNew]",objCon);
                objCom.CommandType = CommandType.StoredProcedure;

                //
                SqlParameter objSqlParam_ID = new SqlParameter("@ID", Id);

                //SqlParameter objSqlParam_Name = new SqlParameter("@Name", objEmployee.Name);
                //SqlParameter objSqlParam_Designation = new SqlParameter("@Designation", objEmployee.Designation);
                //SqlParameter objSqlParam_Department = new SqlParameter("@Department", objEmployee.Department);

                //

                //objSqlParam_ID.Direction = ParameterDirection.Input;
                //objSqlParam_Name.Direction = ParameterDirection.Input;
                //objSqlParam_Designation.Direction = ParameterDirection.Input;
                //objSqlParam_Department.Direction = ParameterDirection.Input;

                //

                objCom.Parameters.Add(objSqlParam_ID);

                //objCom.Parameters.Add(objSqlParam_Name);
                //objCom.Parameters.Add(objSqlParam_Designation);
                //objCom.Parameters.Add(objSqlParam_Department);

                //


                objCon.Open();
                SqlDataReader objSqlDR = objCom.ExecuteReader();
                objSqlDR.Read();
                objEmployee = new Employee();
                objEmployee.Id = Convert.ToInt32(objSqlDR[0]);
                objEmployee.Name = objSqlDR[1].ToString();
                objEmployee.Designation = Convert.ToInt32(objSqlDR[2]);
                objEmployee.Department = Convert.ToInt32(objSqlDR[3]);

                objCon.Close();


            }
            catch (SqlException objSqlEx)
            {
                throw new HRDException(objSqlEx.Message);

            }
            catch (Exception objEx)
            {
                throw new HRDException(objEx.Message);

            }
            return objEmployee;
        }

        public DataTable GetEmployees()
        {
            DataTable objDT;
            try
            {
                SqlConnection objCon = new SqlConnection(ConfigurationManager.ConnectionStrings["HRDConnectionString"].ToString());
                SqlCommand objCom = new SqlCommand("[46008413].[SelectEmployees]", objCon);
                objCom.CommandType = CommandType.StoredProcedure;

                //
                ////SqlParameter objSqlParam_ID = new SqlParameter("@ID", Id);

                //SqlParameter objSqlParam_Name = new SqlParameter("@Name", objEmployee.Name);
                //SqlParameter objSqlParam_Designation = new SqlParameter("@Designation", objEmployee.Designation);
                //SqlParameter objSqlParam_Department = new SqlParameter("@Department", objEmployee.Department);

                //

                //objSqlParam_ID.Direction = ParameterDirection.Input;
                //objSqlParam_Name.Direction = ParameterDirection.Input;
                //objSqlParam_Designation.Direction = ParameterDirection.Input;
                //objSqlParam_Department.Direction = ParameterDirection.Input;

                //

                ////objCom.Parameters.Add(objSqlParam_ID);

                //objCom.Parameters.Add(objSqlParam_Name);
                //objCom.Parameters.Add(objSqlParam_Designation);
                //objCom.Parameters.Add(objSqlParam_Department);

                //


                objCon.Open();
                SqlDataReader objSqlDR = objCom.ExecuteReader();
                
                
                //objSqlDR.Read();
                //objEmployee = new Employee();
                //objEmployee.Id = Convert.ToInt32(objSqlDR[0]);
                //objEmployee.Name = objSqlDR[1].ToString();
                //objEmployee.Designation = Convert.ToInt32(objSqlDR[2]);
                //objEmployee.Department = Convert.ToInt32(objSqlDR[3]);


                objDT = new DataTable();
                objDT.Load(objSqlDR);
              

                objCon.Close();


            }
            catch (SqlException objSqlEx)
            {
                throw new HRDException(objSqlEx.Message);

            }
            catch (Exception objEx)
            {
                throw new HRDException(objEx.Message);

            }
            return objDT;
        }


        public DataTable GetDesignations()
        {
            DataTable objDT;
            try
            {
                SqlConnection objCon = new SqlConnection(ConfigurationManager.ConnectionStrings["HRDConnectionString"].ToString());
                SqlCommand objCom = new SqlCommand("[46008413].[SelectDesignations]", objCon);
                objCom.CommandType = CommandType.StoredProcedure;

                //
                ////SqlParameter objSqlParam_ID = new SqlParameter("@ID", Id);

                //SqlParameter objSqlParam_Name = new SqlParameter("@Name", objEmployee.Name);
                //SqlParameter objSqlParam_Designation = new SqlParameter("@Designation", objEmployee.Designation);
                //SqlParameter objSqlParam_Department = new SqlParameter("@Department", objEmployee.Department);

                //

                //objSqlParam_ID.Direction = ParameterDirection.Input;
                //objSqlParam_Name.Direction = ParameterDirection.Input;
                //objSqlParam_Designation.Direction = ParameterDirection.Input;
                //objSqlParam_Department.Direction = ParameterDirection.Input;

                //

                ////objCom.Parameters.Add(objSqlParam_ID);

                //objCom.Parameters.Add(objSqlParam_Name);
                //objCom.Parameters.Add(objSqlParam_Designation);
                //objCom.Parameters.Add(objSqlParam_Department);

                //


                objCon.Open();
                SqlDataReader objSqlDR = objCom.ExecuteReader();


                //objSqlDR.Read();
                //objEmployee = new Employee();
                //objEmployee.Id = Convert.ToInt32(objSqlDR[0]);
                //objEmployee.Name = objSqlDR[1].ToString();
                //objEmployee.Designation = Convert.ToInt32(objSqlDR[2]);
                //objEmployee.Department = Convert.ToInt32(objSqlDR[3]);


                objDT = new DataTable();
                objDT.Load(objSqlDR);


                objCon.Close();


            }
            catch (SqlException objSqlEx)
            {
                throw new HRDException(objSqlEx.Message);

            }
            catch (Exception objEx)
            {
                throw new HRDException(objEx.Message);

            }
            return objDT;
        }
        public DataTable GetDepartments()
        {
            DataTable objDT;
            try
            {
                SqlConnection objCon = new SqlConnection(ConfigurationManager.ConnectionStrings["HRDConnectionString"].ToString());
                SqlCommand objCom = new SqlCommand("[46008413].[SelectDepartments]", objCon);
                objCom.CommandType = CommandType.StoredProcedure;

                //
                ////SqlParameter objSqlParam_ID = new SqlParameter("@ID", Id);

                //SqlParameter objSqlParam_Name = new SqlParameter("@Name", objEmployee.Name);
                //SqlParameter objSqlParam_Designation = new SqlParameter("@Designation", objEmployee.Designation);
                //SqlParameter objSqlParam_Department = new SqlParameter("@Department", objEmployee.Department);

                //

                //objSqlParam_ID.Direction = ParameterDirection.Input;
                //objSqlParam_Name.Direction = ParameterDirection.Input;
                //objSqlParam_Designation.Direction = ParameterDirection.Input;
                //objSqlParam_Department.Direction = ParameterDirection.Input;

                //

                ////objCom.Parameters.Add(objSqlParam_ID);

                //objCom.Parameters.Add(objSqlParam_Name);
                //objCom.Parameters.Add(objSqlParam_Designation);
                //objCom.Parameters.Add(objSqlParam_Department);

                //


                objCon.Open();
                SqlDataReader objSqlDR = objCom.ExecuteReader();


                //objSqlDR.Read();
                //objEmployee = new Employee();
                //objEmployee.Id = Convert.ToInt32(objSqlDR[0]);
                //objEmployee.Name = objSqlDR[1].ToString();
                //objEmployee.Designation = Convert.ToInt32(objSqlDR[2]);
                //objEmployee.Department = Convert.ToInt32(objSqlDR[3]);


                objDT = new DataTable();
                objDT.Load(objSqlDR);


                objCon.Close();


            }
            catch (SqlException objSqlEx)
            {
                throw new HRDException(objSqlEx.Message);

            }
            catch (Exception objEx)
            {
                throw new HRDException(objEx.Message);

            }
            return objDT;
        }
    }

    }

