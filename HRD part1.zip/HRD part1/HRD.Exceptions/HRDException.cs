﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRD.Exceptions
{
    public class HRDException: ApplicationException
    {

        public HRDException(): base()
        {

        }

         public HRDException(string message): base(message)
        {

        }

        public HRDException(string message, Exception innerException) : base(message, innerException)
        {

        }


    }
}
