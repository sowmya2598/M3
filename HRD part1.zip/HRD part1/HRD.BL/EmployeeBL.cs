﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Text.RegularExpressions;
using HRD.Enties;
using HRD.Exceptions;
using HRD.DAL;


namespace HRD.BL
{
    public class EmployeeBL
    {

        public static bool ValidateEmployee(Employee objEmployee)
        {
            bool employeeValidated = true;
            StringBuilder message = new StringBuilder();

            try
            {
                if (objEmployee.Id <= 0)
                {
                    employeeValidated = false;
                    message.Append("Employee Id must be greater than zero\n");

                }
                //else if (!Regex.IsMatch(objEmployee.Id.ToString(), "^[0-9]{1,3}$"))
                //{
                //    employeeValidated = false;
                //    message.Append("Employee Id is limited to 3 DIGITS ONLY!\n");
                //}



                if (objEmployee.Name == string.Empty)
                {
                    employeeValidated = false;
                    message.Append("Employee name must be provided\n");

                }
                else if (!Regex.IsMatch(objEmployee.Name, "^[A-Z][a-z]+"))
                {
                    employeeValidated = false;
                    message.Append("Employee name must have alphabets only!\n");
                }

                if (objEmployee.Designation <= 0)
                {
                    employeeValidated = false;
                    message.Append("Employee Designation must be greater than zero\n");

                }

                if (objEmployee.Department <= 0)
                {
                    employeeValidated = false;
                    message.Append("Employee Department must be greater than zero\n");

                }
            }

            catch (HRDException objHRDEx)
            {
                throw objHRDEx;
            }
            catch (Exception objEx)
            {
                throw objEx;
            }
            return employeeValidated;



        }
        public static bool  AddEmployee(Employee objEmployee)
        {
            bool employeeAdded;
            try
            {
                if(ValidateEmployee(objEmployee))
                {
                    EmployeeDAL objEmployeeDAL = new EmployeeDAL();
                    employeeAdded = objEmployeeDAL.InsertEmployee(objEmployee);
                }
                else
                {
                    throw new HRDException("Provide the Validate emp details");
                }
                
            }
             catch(HRDException objHRDEx)
            {
                throw objHRDEx;
            }
            catch(Exception objEx)
            {
                throw objEx;
            }
            return employeeAdded;
        }


        public static bool UpdateEmployee(Employee objEmployee)
        {
            bool employeeUpdated;
            try
            {
                if(ValidateEmployee(objEmployee))
                {

               
                EmployeeDAL objEmployeeDAL = new EmployeeDAL();
                employeeUpdated = objEmployeeDAL.UpdateEmployee(objEmployee);


                }
                else
                {
                    throw new HRDException("Provide the Validate emp details");
                }

            }
            catch (HRDException objHRDEx)
            {
                throw objHRDEx;
            }
            catch (Exception objEx)
            {
                throw objEx;
            }
            return employeeUpdated;
        }



        public static bool DeleteEmployee(int Id)
        {

            bool employeeDeleted;
            try
            {
                if(Id <=0)
                {
                    throw new HRDException("Employee Id must be greater than zero");
                }
                else
                {
                    EmployeeDAL objEmployeeDAL = new EmployeeDAL();
                    employeeDeleted = objEmployeeDAL.DeleteEmployee(Id);
                }
                
            }
            catch (HRDException objHRDEx)
            {
                throw objHRDEx;
            }
            catch (Exception objEx)
            {
                throw objEx;
            }
            return employeeDeleted;
        }




        public static Employee SearchEmployee(int id)
        {
            Employee objEmployee;
            try
            {
                if(id<=0 )
                {
                    throw new HRDException("Employee Id must be greater than zero");
                }
                else
                {
                    EmployeeDAL objEmployeeDAL = new EmployeeDAL();
                    objEmployee = objEmployeeDAL.SearchEmployee(id);
                }

            }
            catch (HRDException objHRDEx)
            {
                throw objHRDEx;
            }
            catch (Exception objEx)
            {
                throw objEx;
            }
            return objEmployee;
        }


        public static  DataTable GetEmployees()
        {
            DataTable objDT;
            try
            {
                EmployeeDAL objEmployeeDAL = new EmployeeDAL();
                objDT = objEmployeeDAL.GetEmployees();

            }
            catch (HRDException objHRDEx)
            {
                throw objHRDEx;
            }
            catch (Exception objEx)
            {
                throw objEx;
            }
            return objDT;
        }



        public static DataTable GetDesignations()
        {
            DataTable objDT;
            try
            {
                EmployeeDAL objEmployeeDAL = new EmployeeDAL();
                objDT = objEmployeeDAL.GetDesignations();
            }
            catch (HRDException objHRDEx)
            {
                throw objHRDEx;
            }
            catch (Exception objEx)
            {
                throw objEx;
            }
            return objDT;

        }
        public static DataTable GetDepartments()
        {
            DataTable objDT;
            try
            {
                EmployeeDAL objEmployeeDAL = new EmployeeDAL();
                objDT = objEmployeeDAL.GetDepartments();
            }
            catch (HRDException objHRDEx)
            {
                throw objHRDEx;
            }
            catch (Exception objEx)
            {
                throw objEx;
            }
            return objDT;
        }
    }
    }

