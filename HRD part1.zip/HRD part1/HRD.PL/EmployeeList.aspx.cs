﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using HRD.BL;
using HRD.Enties;
using HRD.Exceptions;

namespace HRD.PL
{
    public partial class EmployeeList : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            GetEmployeeinDisplayPage();
        }






        private void GetEmployeeinDisplayPage()
        {

            try
            {
                //EmployeeBL objEmployeeBL = new EmployeeBL();
                DataTable objDT = EmployeeBL.GetEmployees();
                gvEmployeeDetails.DataSource = objDT.DefaultView;         
                gvEmployeeDetails.DataBind();

            }
            catch (HRDException objHRDEx)
            {
                lblErrorMessage.Text = objHRDEx.Message;

            }
            catch (Exception objEx)
            {
                throw objEx;
            }
        }





    }
}