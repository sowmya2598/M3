﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

using HRD.BL;
using HRD.Enties;
using HRD.Exceptions;



namespace HRD.PL
{
    public partial class AddEmployee : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!Page.IsPostBack)
            {
                GetDesignations();
                GetDepartments();

            }
        }

        protected void btnAddEmployee_Click(object sender, EventArgs e)
        {
            InsertEmployee();
        }

        protected void btnClear_Click(object sender, EventArgs e)
        {
            Clear();
        }

        //


        private void InsertEmployee()
        {
            int id;
            string name;
            int designation;
            int department;

            bool employeeAdded;


            //
            try
            {
                id = Convert.ToInt32(txtId.Text);
                name = txtName.Text;
                designation = Convert.ToInt32(ddlDesignation.SelectedValue);
                department = Convert.ToInt32(ddlDepartment.SelectedValue);

                Employee objEmployee = new Employee
                {
                    Id = id,
                    Name = name,
                    Designation = designation,
                    Department = department
                };





        employeeAdded = EmployeeBL.AddEmployee(objEmployee);
                if (employeeAdded == true)
                {
                    lblErrorMessage.Text = "Employee Record added successfully....";

                }

                else
                {
                    lblErrorMessage.Text = " Employee Record couldn't be  added!";
                }


            }


            catch (HRDException objHRDEx)
            {
                throw objHRDEx;
            }
            catch (Exception objEx)
            {
                throw objEx;
            }
           


    }
        private void GetDesignations()
        {
            DataTable objDT;
            try
            {
                objDT = EmployeeBL.GetDesignations();
                ddlDesignation.DataSource = objDT;
                ddlDesignation.DataTextField = objDT.Columns[1].ToString();
                ddlDesignation.DataValueField = objDT.Columns[0].ToString();
                ddlDesignation.DataBind();
            }

            catch (HRDException objHRDEx)
            {
                throw objHRDEx;
            }
            catch (Exception objEx)
            {
                throw objEx;
            }


        }


        private void GetDepartments()
        {
            DataTable objDT;
            try
            {
                objDT = EmployeeBL.GetDepartments();
                ddlDepartment.DataSource = objDT;
                ddlDepartment.DataTextField = objDT.Columns[1].ToString();
                ddlDepartment.DataValueField = objDT.Columns[0].ToString();
                ddlDepartment.DataBind();
            }
            catch (HRDException objHRDEx)
            {
                throw objHRDEx;
            }
            catch (Exception objEx)
            {
                throw objEx;
            }
        }

        private void Clear()
        {
            txtId.Text = string.Empty;
            txtName.Text = string.Empty;
            ddlDesignation.SelectedIndex = -1;
            ddlDepartment.SelectedIndex = -1;

        }

    }
}