﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using HRD.BL;
using HRD.Enties;
using HRD.Exceptions;


namespace HRD.PL
{
    public partial class DeleteEmployee : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSearchEmployee_Click(object sender, EventArgs e)
        {

            Search_Employee();
        }

        protected void btnDeleteEmployee_Click(object sender, EventArgs e)
        {
            Delete_Employee();
        }

      

        protected void btnClear_Click(object sender, EventArgs e)
        {
            txtId.Text = string.Empty;
            lblDisplayname.Text = string.Empty;
            lblDisplayDesignation.Text = string.Empty;
            lblDisplayDepartment.Text = string.Empty;
        }


        private void Search_Employee()
        {
            int id;
            Employee objEmployee;

            try
            {

          
            id = Convert.ToInt32(txtId.Text);
            objEmployee = EmployeeBL.SearchEmployee(id);
            if (objEmployee != null)
            {
                lblDisplayname.Text = objEmployee.Name;
                lblDisplayDesignation.Text = objEmployee.Designation.ToString();
                lblDisplayDepartment.Text = objEmployee.Department.ToString();
                    

            }
            else
            {
                lblErrorMessage.Text = "Couldn't find any record for the given id...";
            }


        }


            catch (HRDException objHRDEx)
            {
                throw objHRDEx;
            }
            catch (Exception objEx)
            {
                throw objEx;
            }
        }



        private void Delete_Employee()
        {
            int id;
            bool employeeDeleted;
            try
            {
                id = Convert.ToInt32(txtId.Text);
                employeeDeleted = EmployeeBL.DeleteEmployee(id);


                if (employeeDeleted == true)
                {
                    lblErrorMessage.Text = "Employee Record deleted successfully....";

                }

                else
                {
                    lblErrorMessage.Text = " Employee Record couldn't be  deleted!";
                }


            }


            catch (HRDException objHRDEx)
            {
                throw objHRDEx;
            }
            catch (Exception objEx)
            {
                throw objEx;
            }
        }


    }
}